package src;

public class Structure extends Displayable{
    
}
