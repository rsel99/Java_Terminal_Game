package game;

public interface InputObserver {

    abstract void observerUpdate(char inputChar);
}
