package game;

public class Door extends Displayable {

    public Door() {
        System.out.println("Door");
    }

}
